package com.Swabhiman.shiftswap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShiftswapApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShiftswapApplication.class, args);
	}

}
