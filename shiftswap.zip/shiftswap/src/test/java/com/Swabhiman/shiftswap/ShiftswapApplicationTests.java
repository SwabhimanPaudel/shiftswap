package com.Swabhiman.shiftswap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShiftswapApplicationTests {

	@Test
	void contextLoads() {
	}

}
